/* 
 * File:   appcommon.h
 * Author: pj
 *
 * Created on October 4, 2014, 5:09 PM
 */
#ifndef APPCOMMON_H
#define	APPCOMMON_H

#include <uv.h>

typedef int (*ListenerMethod)(uv_stream_t *, ssize_t , uv_buf_t);

class EventLoopDefaultListener {
public:
    EventLoopDefaultListener() {
        initialize(); 
    };    
    ~EventLoopDefaultListener() {
        initialize();
    };
    
    // callback is a pointer to a function, this is not a function declaration
    // int (*listenerMethod)(uv_stream_t *server, ssize_t nread, uv_buf_t buf);
    ListenerMethod listenerMethod;
    
    // setters
    void setUserTokens(int64_t token, void *ptrToken) {
        privateToken = token;
        privatePtrToken = ptrToken;
    };
    
    // getters
    int64_t getToken() { return privateToken;};
    void *getPtrToken() { return privatePtrToken; };
    void initialize() {
        listenerMethod = NULL;
        setUserTokens(0, NULL);
    };
    
private:
    int64_t privateToken;
    void *privatePtrToken;
};

#if 0
class EventLoop {
public:
    static const int MAX_FD_IN_LOOP = 64;
    static const int MAX_EVENTS = 32;
    EventLoop();
    ~EventLoop();
    
    int addFd(int fd, int userData, EventListener *listener);
    int deleteFd(int fd);
    void run();
    
private:
    int initLoopFd();
    int deInitLoopFd();
    void initLocalData();
    void deInitLocalData();
    int addToEventLoop(int fd, int i);
    int deleteFromEventLoop(int fd);
    int deleteFromEventLoop2(int fd, int slot);
    void deleteAllFds();
    void freeSlot(int slot);
    void useSlot(int slot, int fd, int userData, EventListener *listener);
    
    int epfd;
    int fds[MAX_FD_IN_LOOP];
    int userData[MAX_FD_IN_LOOP];  // nanomsg socket
    EventListener *listeners[MAX_FD_IN_LOOP];
};

#endif

extern const int MAX_ALLOCATION_SIZE;

class EventLoop {
    uv_tcp_t defaultServer;
    uv_loop_t *loop;    
    
public:
    EventLoop(uint16_t defaultPort = 7000);
    ~EventLoop();
    int run();
    int addDefaultServerPort(uint16_t defaultPort = 7000);
    uv_loop_t *getEventLoop() {
        return loop;
    }
    ListenerMethod *defaultListener;
};

class Application {
    char progName[32];
    char appName[64];
    int appInstance;
    EventLoop *eventLoop;

public:
    Application();
    Application(const int argc, const char *argv[]);
    ~Application();
    int run();
    int initServerActivities(uint16_t defaultPort = 7000);
    void initialize(const int argc, const char *argv[]);
    EventLoop *getEventLoop() {
        return eventLoop;
    }
};

#if 0
class ServerApplication : public Application {
    EventLoop *eventLoop;
public:
    ServerApplication();
    ServerApplication(const int argc, const char *argv[]);
    ~ServerApplication();
    int initServerActivities();
    EventLoop *getEventLoop() {
        return eventLoop;
    }
};
#endif

#endif	/* APPCOMMON_H */

